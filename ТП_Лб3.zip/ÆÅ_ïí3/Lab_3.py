
'''

Задание	6.1
Аналогично	заданию	3.1	обработать	строки	из	файла	ospf.txt
и	вывести	информацию по	каждой	в	таком	виде:	Protocol:
OSPF	Prefix:	10.0.24.0/24	AD/Metric:	110/41	Next-Hop:
10.0.13.3	Last	update:	3d18h	Outbound	Interface:
FastEthernet0/0

'''

# %% 6.1
with open('OSPF.txt', 'r') as f:
    print(f.read().replace('Fast', 'Gigabit'))


'''

Задание	6.2
Создать	скрипт,	который	будет	обрабатывать	конфигурационный	файл	config_sw1.txt: имя	файла	передается	как	аргумент	скрипту
Скрипт	должен	возвращать	на	стандартный	поток	вывода	
команды	из	переданного конфигурационного	файла,	исключая 
строки,	которые	начинаются	с	'!'.
Между	строками	не	должно	быть	дополнительного	символа	
перевода	строки.


'''

# %% 6.2
def task6_2(file_name):
    with open(file_name, 'r') as f:
        file = f.readlines()
    for s in file:
        if s[0] != '!':
            print(s.rstrip())


task6_2('config_sw1.txt')

'''

Задание	6.2a
Сделать	копию	скрипта	задания	6.2.
Дополнить	скрипт:
Задания
204
Скрипт	не	должен	выводить	команды,	в	которых	
содержатся	слова,	которые указаны	в	списке	ignore.
Ограничение:	Все	задания	надо	выполнять	используя	
только	пройденные	темы.
ignore	=	['duplex',	'alias',	'Current	configuration']


'''

# %% 6.2 a
def task6_2_a(file_name):
    ignore = ['duplex', 'alias', 'Current	configuration']
    with open(file_name, 'r') as f:
        file = f.readlines()
    for s in file:
        flag = True
        if s[0] == '!':
            flag = False
        for bw in ignore:
            if bw in s:
                flag = False
        if flag:
            print(s.rstrip())


task6_2_a('config_sw1.txt')

'''

Задание	6.2b
Дополнить	скрипт	из	задания	6.2a:
вместо	вывода	на	стандартный	поток	вывода,	скрипт	должен	
записать	полученные строки	в	файл	config_sw1_cleared.txt
При	этом,	должны	быть	отфильтрованы	строки,	которые	
содержатся	в	списке	ignore. Строки,	которые	начинаются	
на	'!'	отфильтровывать	не	нужно.
Ограничение:	Все	задания	надо	выполнять	используя	
только	пройденные	темы.
ignore	=	['duplex',	'alias',	'Current	configuration']

'''

# %% 6.2 b
def task6_2_b(file_name):
    ignore = ['duplex', 'alias', 'Current	configuration']
    with open(file_name, 'r') as f:
        file = f.readlines()
    with open('config_sw1_cleared.txt', 'w') as f:
        f.write('')
    with open('config_sw1_cleared.txt', 'a') as f:
        for s in file:
            flag = True
            for bw in ignore:
                if bw in s:
                    flag = False
            if flag:
                f.write(s)


task6_2_b('config_sw1.txt')

'''

Задание	6.2c
Переделать	скрипт	из	задания	6.2b: передавать	как	
аргументы	скрипту: имя	исходного	файла	конфигурации 
имя	итогового	файла	конфигурации
Внутри,	скрипт	должен	отфильтровать	те	строки,	в	
исходном	файле	конфигурации,	в которых	содержатся	
слова	из	списка	ignore.	И	затем	записать	оставшиеся	
строки	в итоговый	файл.
Проверить	работу	скрипта	на	примере	файла	config_sw1.txt.
Ограничение:	Все	задания	надо	выполнять	используя	
только	пройденные	темы.
ignore	=	['duplex',	'alias',	'Current	configuration']


'''

# %% 6.2 c
def task6_2_c(input_file_name, output_file_name):
    ignore = ['duplex', 'alias', 'Current	configuration']
    with open(input_file_name, 'r') as f:
        file = f.readlines()
    with open(output_file_name, 'w') as f:
        f.write('')
    with open(output_file_name, 'a') as f:
        for s in file:
            flag = True
            for bw in ignore:
                if bw in s:
                    flag = False
            if flag:
                f.write(s)


task6_2_c('config_sw1.txt', 'config_sw1_cleared.txt')

'''

Задание	6.3
Скрипт	должен	обрабатывать	записи	в	файле	
CAM_table.txt	таким	образом	чтобы:
Задания
205
считывались	только	строки,	в	которых	указаны	MAC-адреса 
каждая	строка,	где	есть	MAC-адрес,	должна	обрабатываться	
таким	образом, чтобы	на	стандартный	поток	вывода	была	
выведена	таблица	вида:
	100				01bb.c580.7000			Gi0/1	
	200				0a4b.c380.7010			Gi0/2	
	300				a2ab.c5a0.2000			Gi0/3	
	100				0a1b.1c80.7300			Gi0/4	
	500				02b1.3c80.7000			Gi0/5	
	200				1a4b.c580.5000			Gi0/6	
	300				0a1b.5c80.9010			Gi0/7
Ограничение:	Все	задания	надо	выполнять	используя	
только	пройденные	темы.


'''

# %% 6.3
with open('CAM_table.txt', 'r') as f:
    file = f.readlines()
macs = []
for i in file[6:]:
    print(i.rstrip())
    macs.append(i.split()[1])
print(macs)

'''

Задание	6.3a
Сделать	копию	скрипта	задания	6.3
Дополнить	скрипт:
Отсортировать	вывод	по	номеру	VLAN

'''

# %% 6.3 a
with open('CAM_table.txt', 'r') as f:
    file = f.readlines()
file = sorted(file[6:], key=lambda e: e[1])
for i in file:
    print(i.rstrip())

'''

Задание	6.3b
Сделать	копию	скрипта	задания	6.3a
Дополнить	скрипт:
Запросить	у	пользователя	ввод	номера	VLAN. 
Выводить	информацию	только	по	указанному	VLAN.

'''

# %% 6.3 b
inp_vlan = input('Введите VLAN id:  ')
with open('CAM_table.txt', 'r') as f:
    file = f.readlines()
for i in file[6:]:
    if inp_vlan == i.split()[0]:
        print(i.rstrip())
