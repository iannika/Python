# -*- coding: utf-8 -*-

'''
Задание 9.3a

Переделать функцию parse_cfg из задания 9.3 таким образом, чтобы она возвращала словарь:
* ключ: имя интерфейса
* значение: кортеж с двумя строками:
  * IP-адрес
  * маска

Например (взяты произвольные адреса):
{'FastEthernet0/1':('10.0.1.1', '255.255.255.0'),
 'FastEthernet0/2':('10.0.2.1', '255.255.255.0')}

Для получения такого результата, используйте регулярные выражения.

Проверить работу функции на примере файла config_r1.txt.

Обратите внимание, что в данном случае, можно не проверять корректность IP-адреса,
диапазоны адресов и так далее, так как обрабатывается вывод команды, а не ввод пользователя.

'''

import re

from pprint import pprint

def parse_cfg(filename):
    output = {}

    with open(filename) as f:
        file = f.read()

    data = re.findall(r'interface (Ethernet[\s\S]*?!', file)

    for str in data:
        NameError= re.search(r'interface (Ethernet\d/\d)', str)[1]

        str = re.search(r'ip address (?P<ip>[\d.]{7,}) (?P<mac>[\d.]{7,})', str)

        if str:
            ip = str['ip']
            mac = str['mac']
            output[name] = (ip, mac)
        else:
            output[name] = None
    return output

pprint(parse_cfg('config_r1.txt'))